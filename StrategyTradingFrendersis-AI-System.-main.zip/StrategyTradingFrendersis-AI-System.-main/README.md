# Strategy Trading Frendersis AI-System.
Strategy Trading Frendersis AI-System.
